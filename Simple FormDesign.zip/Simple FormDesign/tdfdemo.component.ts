import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-tdfdemo',
  templateUrl: './tdfdemo.component.html',
  styleUrls: ['./tdfdemo.component.css']
})
export class TDFDemoComponent implements OnInit {

//  type:string="password";

cityMethod:any[]=[

  {
    id:1,
    name:"Nagpur"
  },
    {
      id:2,
      name:"Pune"
    },
    {
      id:3,
      name:"Mumbai"
    }
];

Email_Pattern="^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
  constructor() { }

  ngOnInit() {
  }

  onSubmit(f)
  {
    console.log(f.value.myusername);
    console.log(f.value.mypassword);
    console.log(f.value.email);
    console.log(f.value.con);
    console.log(f.value.city);
    console.log(f.value.comment);
    console.log(f.value.subScribe);

    //if you want to add data in json formate then
    let obj={
      username:f.value.myusername,
      password:f.value.mypassword,
      email:f.value.email,
      con:f.value.con,
      city:f.value.city,
      comment:f.value.comment,
      subscribe:f.value.subScribe
    }
    
  }


}
